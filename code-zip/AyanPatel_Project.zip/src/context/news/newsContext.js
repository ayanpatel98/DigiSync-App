import { createContext } from "react";

const newsContext = createContext();

export default newsContext;