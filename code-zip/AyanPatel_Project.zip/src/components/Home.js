import React from 'react'
import TopHeadlines from './TopHeadlines';

const Home = () => {

    return (
        <>
            <TopHeadlines />
        </>
    )
}

export default Home;